﻿using System;

namespace ConsoleApp2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Ваше имя: ");
            string name = Console.ReadLine();
            string name2 = "Вячеслав";
            if (name == name2)
                Console.WriteLine("Привет");
            else
                Console.WriteLine("Нет такого имени");
        }
    }
}
