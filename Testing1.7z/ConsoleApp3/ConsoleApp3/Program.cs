﻿using System;

namespace ConsoleApp3
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write(" Введите число: ");
            int a = Convert.ToInt16(Console.ReadLine());
            int b = 7;
            if (a > b)
                Console.WriteLine("Привет");
        }
    }
}
