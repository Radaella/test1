﻿using System;

namespace ConsoleApp3
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write(" Введите число: ");
            // Ввод числа. Чтобы сразу получить число, используйте методы класса Convert
            int a = Convert.ToInt16(Console.ReadLine());
            int b = 7;
            if (a > b)
                Console.WriteLine("Привет");
        }
    }
}
